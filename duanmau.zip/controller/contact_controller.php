<?php 

function show_contact()
{
    render("contact");
}
