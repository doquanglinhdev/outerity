<?php 

function show_error()
{
    render("404");
}
