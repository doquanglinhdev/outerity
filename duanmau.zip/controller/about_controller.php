<?php 

function show_about()
{
    render("about");
}
