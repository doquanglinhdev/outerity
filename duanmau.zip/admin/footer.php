    <!-- Main Footer -->
    <footer class="main-footer">
      <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
      All rights reserved.
      <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 3.2.0
      </div>
    </footer>
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <script src="//cdn.ckeditor.com/4.20.0/full/ckeditor.js"></script>
  <!-- jQuery -->
  <script src="admin/assets/js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="admin/assets/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE -->
  <script src="admin/assets/js/adminlte.js"></script>

  <!-- OPTIONAL SCRIPTS -->
  <!-- <script src="plugins/chart.js/Chart.min.js"></script> -->
  <script src="admin/assets/js/dashboard3.js"></script>
</body>

</html>